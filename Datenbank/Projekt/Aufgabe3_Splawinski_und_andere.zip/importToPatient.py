import cx_Oracle

connection = cx_Oracle.connect('s864976/student@localhost:1521/oracle')
cursor = connection.cursor()


cursor.execute('insert into PATIENT (PATIENTNR) select distinct ANONID from AOLDATA.QUERYDATA where QUERY like \'%bladder%cancer%\' or QUERY like \'%cancer%bladder%\' or QUERY like \'%breast%cancer%\' or QUERY like \'%cancer%breast%\' or QUERY like \'%colorectal%cancer%\' or QUERY like \'%cancer%colorectal%\' or QUERY like \'%bowel%cancer%\' or QUERY like \'%cancer%bowel%\' or QUERY like \'%kidney%cancer%\' or QUERY like \'%cancer%kidney%\' or QUERY like \'%lung%cancer%\' or QUERY like \'%cancer%lung%\'or QUERY like \'%lymphoma%cancer%\' or QUERY like \'%cancer%lymphoma%\' or QUERY like \'%melanoma%cancer%\' or QUERY like \'%cancer%melanoma%\' or QUERY like \'%oral%cancer%\' or QUERY like \'%cancer%oral%\' or QUERY like \'%oesophageal%cancer%\' or QUERY like \'%cancer%oesophageal%\' or QUERY like \'%pancreatic%cancer%\' or QUERY like \'%cancer%pancreatic%\' or QUERY like \'%prostate%cancer%\' or QUERY like \'%cancer%prostate%\' or QUERY like \'%thyroid%cancer%\' or QUERY like \'%cancer%thyroid%\' or QUERY like \'%uterine%cancer%\' or QUERY like \'%cancer%uterine%\' and ANONID not in (select PATIENTNR as ANONID from PATIENT)')

connection.commit()
cursor.execute('SELECT * FROM PATIENT')
result = cursor.fetchall()

for row in result:
    print(row)

cursor.close()
connection.close()


