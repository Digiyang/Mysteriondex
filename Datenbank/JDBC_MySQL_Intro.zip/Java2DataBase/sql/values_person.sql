insert into person (person_id, first_name, last_name, born_date) 
	values (6144000434943451206, 'Bill', 'Smith', '1969-01-01');
insert into person (person_id, first_name, last_name, born_date) 
	values (297806464197500561, 'Inga', 'Jones', '1970-09-24');
insert into person (person_id, first_name, last_name, born_date) 
	values (2208189410429574150, 'Moritz', 'Youngster', '1997-02-24');
insert into person (person_id, first_name, last_name, born_date) 
	values (7276586290201554280, 'Bob', 'Builder', '1976-04-20');
insert into person (person_id, first_name, last_name, born_date) 
	values (1658111608567355835, 'Homer', 'Simpson','1995-01-01');
insert into person (person_id, first_name, last_name, born_date) 
	values (2958682298118957594, 'Jesus', 'Christus', '0000-12-24');
insert into person (person_id, first_name, last_name, born_date) 
	values (4595116680171429517, 'Mathilde','Baby', '2011-01-19');