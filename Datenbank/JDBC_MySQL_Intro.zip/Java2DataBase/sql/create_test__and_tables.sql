create database test;
use test;
 
create table person (
person_id BIGINT,
first_name VARCHAR(100),
last_name VARCHAR(100),
born_date DATE 
);
 
