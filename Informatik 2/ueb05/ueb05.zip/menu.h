#ifndef MENU_H
#define MENU_H

int getMenu(char * menutitle, char * menupoints[], int numberOfPoints);

#endif // MENU_H

