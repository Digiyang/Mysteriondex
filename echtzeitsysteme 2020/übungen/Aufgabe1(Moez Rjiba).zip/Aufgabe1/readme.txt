Aufgabe1: 
prototype_process.c --> test process | make prototype_process
queuedemo.c --> test queue | make queuedemo | make clean1
queuedemoerror.c --> test queue when empty --> error(stderr) | make queuedemoerror | make clean2
main --> demo programm | make run | make clean0

